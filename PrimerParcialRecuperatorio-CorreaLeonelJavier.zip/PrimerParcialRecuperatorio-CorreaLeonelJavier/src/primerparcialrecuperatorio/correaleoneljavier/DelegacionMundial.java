package primerparcialrecuperatorio.correaleoneljavier;

import java.util.ArrayList;
import java.util.List;

/**
 * Representa la delegacion de participantes acreditados en el Mundial.
 */
public class DelegacionMundial {

    private String nombre;
    private List<Participante> participantes;

    /**
     * Constructor para la delegacion.
     *
     * @param nombre Nombre de la delegacion.
     */
    public DelegacionMundial(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        this.participantes = new ArrayList<>();
    }

    private void validarNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de la delegacion no puede ser nulo o vacio.");
        }
    }

    /**
     * Agrega un participante a la delegacion.
     *
     * @param p Participante a agregar.
     * @throws ParticipanteDuplicadoException Si el participante ya esta
     * registrado.
     */
    public void agregarParticipante(Participante p) throws ParticipanteDuplicadoException {
        validarParticipante(p);
        if (participantes.contains(p)) {
            throw new ParticipanteDuplicadoException("Ya existe un participante llamado '" + p.getNombre() + "' que representa a '" + p.getPais() + "'.");
        }
        participantes.add(p);
    }

    private void validarParticipante(Participante p) {
        if (p == null) {
            throw new IllegalArgumentException("El participante a agregar no puede ser nulo.");
        }
    }

    /**
     * Obtiene la lista de todos los participantes registrados.
     *
     * @return Lista de participantes.
     */
    public List<Participante> obtenerParticipantes() {
        return new ArrayList<>(participantes);
    }

    /**
     * Filtra y devuelve los participantes con el nivel de experiencia
     * especificado.
     *
     * @param exp Nivel de experiencia a buscar.
     * @return Lista de participantes filtrados.
     */
    public List<Participante> filtrarPorExperiencia(NivelExperiencia exp) {
        validarExperiencia(exp);
        List<Participante> filtrados = new ArrayList<>();
        for (Participante p : participantes) {
            if (p.getExperiencia() == exp) {
                filtrados.add(p);
            }
        }
        return filtrados;
    }

    private void validarExperiencia(NivelExperiencia exp) {
        if (exp == null) {
            throw new IllegalArgumentException("El nivel de experiencia para filtrar no puede ser nulo.");
        }
    }
}
