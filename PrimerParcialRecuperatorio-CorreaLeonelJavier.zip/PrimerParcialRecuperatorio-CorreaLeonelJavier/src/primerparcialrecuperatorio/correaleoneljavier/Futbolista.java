package primerparcialrecuperatorio.correaleoneljavier;

/**
 * Clase que representa a un futbolista, el cual puede entrenar.
 */
public abstract class Futbolista extends Participante implements Entrenable {

    private final int numeroCamiseta;
    private final int partidosDisputados;

    /**
     * Constructor de Futbolista.
     *
     * @param nombre Nombre del futbolista.
     * @param pais Pais que representa.
     * @param experiencia Nivel de experiencia.
     * @param numeroCamiseta Numero de camiseta.
     * @param partidosDisputados Cantidad de partidos disputados.
     */
    public Futbolista(String nombre, String pais, NivelExperiencia experiencia,
            int numeroCamiseta, int partidosDisputados) {
        super(nombre, pais, experiencia);
        this.numeroCamiseta = numeroCamiseta;
        this.partidosDisputados = partidosDisputados;
    }

    public int getNumeroCamiseta() {
        return numeroCamiseta;
    }

    public int getPartidosDisputados() {
        return partidosDisputados;
    }

    @Override
    public String entrenar() {
        return "El futbolista " + getNombre() + " de " + getPais() + " realizo el entrenamiento.";
    }
}
