package primerparcialrecuperatorio.correaleoneljavier;

/**
 * Representa a un arbitro en el Mundial.
 */
public class Arbitro extends Participante implements Informable {

    private int partidosDirigidos;

    /**
     * Constructor de Arbitro.
     *
     * @param nombre Nombre del arbitro.
     * @param pais Pais que representa.
     * @param experiencia Nivel de experiencia.
     * @param partidosDirigidos Cantidad de partidos dirigidos.
     */
    public Arbitro(String nombre, String pais, NivelExperiencia experiencia, int partidosDirigidos) {
        super(nombre, pais, experiencia);
        this.partidosDirigidos = partidosDirigidos;
    }

    public int getPartidosDirigidos() {
        return partidosDirigidos;
    }

    @Override
    public String generarInforme() {
        return "Informe del arbitro " + getNombre() + ": " + partidosDirigidos + " partidos dirigidos.";
    }

    @Override
    public String toString() {
        return "Arbitro [nombre=" + getNombre()
                + ", pais=" + getPais()
                + ", experiencia=" + getExperiencia()
                + ", partidosDirigidos=" + partidosDirigidos + "]";
    }
}
