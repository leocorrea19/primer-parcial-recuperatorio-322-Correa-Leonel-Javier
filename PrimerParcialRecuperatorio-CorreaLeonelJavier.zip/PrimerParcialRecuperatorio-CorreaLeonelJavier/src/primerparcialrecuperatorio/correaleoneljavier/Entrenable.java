package primerparcialrecuperatorio.correaleoneljavier;

/**
 * Interfaz para los participantes que pueden realizar entrenamientos.
 */
public interface Entrenable {

    /**
     * Realiza un entrenamiento y devuelve un mensaje descriptivo.
     *
     * @return Mensaje descriptivo del entrenamiento.
     */
    String entrenar();
}
