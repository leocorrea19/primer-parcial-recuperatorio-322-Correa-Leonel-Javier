package primerparcialrecuperatorio.correaleoneljavier;

import java.util.Objects;

/**
 * Clase abstracta que representa a un participante en el Mundial.
 */
public abstract class Participante {

    private final String nombre;
    private final String pais;
    private final NivelExperiencia experiencia;

    /**
     * Constructor para inicializar los datos comunes de un participante.
     *
     * @param nombre Nombre del participante.
     * @param pais Pais al que representa.
     * @param experiencia Nivel de experiencia.
     */
    public Participante(String nombre, String pais, NivelExperiencia experiencia) {
        this.nombre = nombre;
        this.pais = pais;
        this.experiencia = experiencia;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPais() {
        return pais;
    }

    public NivelExperiencia getExperiencia() {
        return experiencia;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Participante)) {
            return false;
        }
        Participante participante = (Participante) obj;
        return Objects.equals(this.nombre, participante.nombre)
                && Objects.equals(this.pais, participante.pais);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, pais);
    }
}