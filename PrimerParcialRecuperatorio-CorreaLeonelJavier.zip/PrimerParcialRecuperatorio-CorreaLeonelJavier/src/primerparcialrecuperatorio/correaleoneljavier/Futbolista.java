package primerparcialrecuperatorio.correaleoneljavier;

/**
 * Clase abstracta que representa a un futbolista, el cual puede entrenar.
 */
public abstract class Futbolista extends Participante implements Entrenable {

    private int numeroCamiseta;
    private int partidosDisputados;

    /**
     * Constructor de Futbolista.
     *
     * @param nombre Nombre del futbolista.
     * @param pais Pais que representa.
     * @param experiencia Nivel de experiencia.
     * @param numeroCamiseta Numero de camiseta.
     * @param partidosDisputados Cantidad de partidos disputados.
     */
    public Futbolista(String nombre, String pais, NivelExperiencia experiencia, int numeroCamiseta,
            int partidosDisputados) {
        super(nombre, pais, experiencia);
        validarAtributos(numeroCamiseta, partidosDisputados);
        this.numeroCamiseta = numeroCamiseta;
        this.partidosDisputados = partidosDisputados;
    }

    private void validarAtributos(int numeroCamiseta, int partidosDisputados) {
        if (numeroCamiseta <= 0) {
            throw new IllegalArgumentException("El numero de camiseta debe ser mayor a 0.");
        }
        if (partidosDisputados < 0) {
            throw new IllegalArgumentException("La cantidad de partidos disputados no puede ser negativa.");
        }
    }

    @Override
    public String getDescripcion() {
        return super.getDescripcion() + ", numeroCamiseta=" + numeroCamiseta + ", partidosDisputados=" + partidosDisputados;
    }

    public int getNumeroCamiseta() {
        return numeroCamiseta;
    }

    public int getPartidosDisputados() {
        return partidosDisputados;
    }

    @Override
    public String entrenar() {
        return "El futbolista " + getNombre() + " de " + getPais() + " realizo el entrenamiento.";
    }
}
