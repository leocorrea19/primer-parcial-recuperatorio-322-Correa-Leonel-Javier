package primerparcialrecuperatorio.correaleoneljavier;

import java.util.Objects;

/**
 * Clase abstracta que representa a un participante en el Mundial.
 */
public abstract class Participante {

    private String nombre;
    private String pais;
    private NivelExperiencia experiencia;

    /**
     * Constructor para inicializar los datos comunes de un participante.
     *
     * @param nombre Nombre del participante.
     * @param pais Pais al que representa.
     * @param experiencia Nivel de experiencia.
     */
    public Participante(String nombre, String pais, NivelExperiencia experiencia) {
        validarAtributos(nombre, pais, experiencia);
        this.nombre = nombre;
        this.pais = pais;
        this.experiencia = experiencia;
    }

    private void validarAtributos(String nombre, String pais, NivelExperiencia experiencia) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede ser nulo o vacio.");
        }
        if (pais == null || pais.trim().isEmpty()) {
            throw new IllegalArgumentException("El pais no puede ser nulo o vacio.");
        }
        if (experiencia == null) {
            throw new IllegalArgumentException("El nivel de experiencia no puede ser nulo.");
        }
    }

    /**
     * Devuelve una descripcion textual con los datos especificos del
     * participante
     *
     * @return Descripcion del participante.
     */
    public String getDescripcion() {
        return "nombre=" + nombre + ", pais=" + pais + ", experiencia=" + experiencia;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + " [" + getDescripcion() + "]";
    }

    public String getNombre() {
        return nombre;
    }

    public String getPais() {
        return pais;
    }

    public NivelExperiencia getExperiencia() {
        return experiencia;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Participante)) {
            return false;
        }
        Participante other = (Participante) obj;
        return Objects.equals(this.nombre, other.nombre)
                && Objects.equals(this.pais, other.pais);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, pais);
    }
}
