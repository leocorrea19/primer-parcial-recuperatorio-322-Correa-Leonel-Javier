package primerparcialrecuperatorio.correaleoneljavier;

/**
 * Representa los niveles de experiencia de los participantes
 */
public enum NivelExperiencia {
    DEBUTANTE,
    EXPERIMENTADO,
    VETERANO
}
