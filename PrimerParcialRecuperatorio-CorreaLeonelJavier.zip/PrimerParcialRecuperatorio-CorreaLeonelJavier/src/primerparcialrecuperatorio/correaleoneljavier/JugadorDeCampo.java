package primerparcialrecuperatorio.correaleoneljavier;

/**
 * Representa a un jugador de campo en el Mundial.
 */
public class JugadorDeCampo extends Futbolista {
    private int golesConvertidos;

    /**
     * Constructor de JugadorDeCampo.
     * 
     * @param nombre Nombre del jugador.
     * @param pais Pais que representa.
     * @param experiencia Nivel de experiencia.
     * @param numeroCamiseta Numero de camiseta.
     * @param partidosDisputados Cantidad de partidos jugados.
     * @param golesConvertidos Cantidad de goles hechos.
     */
    public JugadorDeCampo(String nombre, String pais, NivelExperiencia experiencia, 
            int numeroCamiseta, int partidosDisputados, int golesConvertidos) {
        super(nombre, pais, experiencia, numeroCamiseta, partidosDisputados);
        this.golesConvertidos = golesConvertidos;
    }

    public int getGolesConvertidos() {
        return golesConvertidos;
    }

    @Override
    public String toString() {
        return "JugadorDeCampo [nombre=" + getNombre() + 
               ", pais=" + getPais() + 
               ", experiencia=" + getExperiencia() + 
               ", numeroCamiseta=" + getNumeroCamiseta() + 
               ", partidosDisputados=" + getPartidosDisputados() + 
               ", golesConvertidos=" + golesConvertidos + "]";
    }
}

