package primerparcialrecuperatorio.correaleoneljavier;

/**
 * Interfaz para los participantes que pueden generar un informe de rendimiento.
 */
public interface Informable {

    /**
     * Genera un informe sobre el desempeño del participante.
     *
     * @return El informe en formato de texto.
     */
    String generarInforme();
}
