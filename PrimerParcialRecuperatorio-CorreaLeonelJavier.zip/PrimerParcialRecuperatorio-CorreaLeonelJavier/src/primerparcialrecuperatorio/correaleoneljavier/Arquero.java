package primerparcialrecuperatorio.correaleoneljavier;

/**
 * Representa a un arquero en el Mundial.
 */
public class Arquero extends Futbolista implements Informable {

    private int atajadasRealizadas;

    /**
     * Constructor de Arquero.
     *
     * @param nombre Nombre del arquero.
     * @param pais Pais que representa.
     * @param experiencia Nivel de experiencia.
     * @param numeroCamiseta Numero de camiseta.
     * @param partidosDisputados Cantidad de partidos jugados.
     * @param atajadasRealizadas Cantidad de atajadas.
     */
    public Arquero(String nombre, String pais, NivelExperiencia experiencia, int numeroCamiseta, int partidosDisputados,
            int atajadasRealizadas) {
        super(nombre, pais, experiencia, numeroCamiseta, partidosDisputados);
        validarAtributos(atajadasRealizadas);
        this.atajadasRealizadas = atajadasRealizadas;
    }

    private void validarAtributos(int atajadasRealizadas) {
        if (atajadasRealizadas < 0) {
            throw new IllegalArgumentException("La cantidad de atajadas realizadas no puede ser negativa.");
        }
    }

    public int getAtajadasRealizadas() {
        return atajadasRealizadas;
    }

    @Override
    public String generarInforme() {
        return "Informe del arquero " + getNombre() + ": " + atajadasRealizadas + " atajadas en "
                + getPartidosDisputados() + " partidos.";
    }

    @Override
    public String getDescripcion() {
        return super.getDescripcion() + ", atajadasRealizadas=" + atajadasRealizadas;
    }
}
