package primerparcialrecuperatorio.correaleoneljavier;

import java.util.ArrayList;
import java.util.List;

/**
 * Representa la delegacion de participantes acreditados en el Mundial.
 */
public class DelegacionMundial {

    private final String nombre;
    private final List<Participante> participantes;

    /**
     * Constructor para la delegacion.
     *
     * @param nombre Nombre de la delegacion.
     */
    public DelegacionMundial(String nombre) {
        this.nombre = nombre;
        this.participantes = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    /**
     * Agrega un participante a la delegacion.
     *
     * @param participante Participante a agregar.
     * @throws ParticipanteDuplicadoException Si el participante ya esta
     * registrado.
     */
    public void agregarParticipante(Participante participante) throws ParticipanteDuplicadoException {
        if (participantes.contains(participante)) {
            throw new ParticipanteDuplicadoException("Ya existe un participante llamado '"
                    + participante.getNombre() + "' que representa a '" + participante.getPais() + "'.");
        }
        participantes.add(participante);
    }

    /**
     * Obtiene la lista de todos los participantes registrados.
     *
     * @return Lista de participantes.
     */
    public List<Participante> obtenerParticipantes() {
        return new ArrayList<>(participantes);
    }

    /**
     * Filtra y devuelve los participantes con el nivel de experiencia
     * especificado.
     *
     * @param experiencia Nivel de experiencia a buscar.
     * @return Lista de participantes filtrados.
     */
    public List<Participante> filtrarPorExperiencia(NivelExperiencia experiencia) {
        List<Participante> filtrados = new ArrayList<>();
        for (Participante participante : participantes) {
            if (participante.getExperiencia() == experiencia) {
                filtrados.add(participante);
            }
        }
        return filtrados;
    }
}
