package primerparcialrecuperatorio.correaleoneljavier;

/**
 * Excepcion que se lanza cuando se intenta registrar un participante
 * que ya existe en la delegacion
 */
public class ParticipanteDuplicadoException extends Exception {
    /**
     * Construye la excepcion con un mensaje pasado por parametros
     * 
     * @param mensaje Mensajo con el error
     */
    public ParticipanteDuplicadoException(String mensaje) {
        super(mensaje);
    }
}

